package com.barclaycard.interviews.airportbaggagerouting.beanmodal;

/**
 * Created by rgalanki on 4/14/18
 */
public class ShortestPathGraphMapException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ShortestPathGraphMapException(String message) {
        super(message);
    }
}
