package com.barclaycard.interviews.airportbaggagerouting.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.barclaycard.interviews.airportbaggagerouting.beanmodal.BagBean;
import com.barclaycard.interviews.airportbaggagerouting.beanmodal.DirectedEdgeBean;

public class AirportBaggageInputUtil {
	public final static String INPUT_DATA_SECTION_HEAD = "# Section:";
	public final static String FLIGHT_ARRIVAL = "ARRIVAL";
	public final static String DEST_BAGGAGE_CLAIM = "BaggageClaim";
	public final static String SINGLE_WHITE_SPACE = " ";

	public static Scanner promptAndParse() {
		System.out.println("Please input the data here:");
		Scanner scan = new Scanner(System.in);
		return scan;
	}

	public static List<DirectedEdgeBean> parseInputGraph(Scanner scanner) {
		String graphSection = scanner.nextLine();
		if (!graphSection.startsWith(INPUT_DATA_SECTION_HEAD)) {
			throw new IllegalArgumentException(
					"Illegal arguments or inputs. Please refer to readme for the input data format.");
		}
		String next = scanner.nextLine();
		List<DirectedEdgeBean> edges = new ArrayList<>();
		while (!next.startsWith(INPUT_DATA_SECTION_HEAD)) {
			String[] parts = next.trim().split("\\s+");
			if (parts.length >= 3) {
				DirectedEdgeBean directedEdge = new DirectedEdgeBean(parts[0], parts[1], Integer.valueOf(parts[2]));
				edges.add(directedEdge);
				// Since it is bi-direction edge, will add another direction edge too.
				DirectedEdgeBean rDirectedEdge = new DirectedEdgeBean(parts[1], parts[0], Integer.valueOf(parts[2]));
				edges.add(rDirectedEdge);
			} else {
				throw new IllegalArgumentException(
						"Illegal arguments or inputs. Please refer to readme for the input data format.");
			}
			next = scanner.nextLine();
		}
		return edges;
	}

	public static Map<String, String> parseInputDepartures(Scanner scanner) {
		String next = scanner.nextLine();
		Map<String, String> departuresMap = new HashMap<>();
		while (!next.startsWith(INPUT_DATA_SECTION_HEAD)) {
			String[] parts = next.trim().split("\\s+");
			if (parts.length >= 2) {
				departuresMap.put(parts[0], parts[1]);
			} else {
				throw new IllegalArgumentException(
						"Illegal arguments or inputs. Please refer to readme for the input data format.");
			}
			next = scanner.nextLine();
		}
		return departuresMap;
	}

	public static List<BagBean> parseInputBags(Scanner scanner) {
		String next;
		List<BagBean> bagList = new ArrayList<>();
		do {
			next = scanner.nextLine();
			String[] parts = next.trim().split("\\s+");
			if (parts.length >= 3) {
				BagBean bag = new BagBean(parts[0], parts[1], parts[2]);
				bagList.add(bag);
			} else {
				scanner.close();
				break;
			}
		} while (scanner.hasNextLine());
		return bagList;
	}
}
