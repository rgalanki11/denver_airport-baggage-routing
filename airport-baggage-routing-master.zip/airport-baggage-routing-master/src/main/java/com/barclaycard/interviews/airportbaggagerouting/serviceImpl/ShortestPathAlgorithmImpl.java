package com.barclaycard.interviews.airportbaggagerouting.serviceImpl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.barclaycard.interviews.airportbaggagerouting.beanmodal.DirectedEdgeBean;
import com.barclaycard.interviews.airportbaggagerouting.beanmodal.ShortestPathGraphMap;
import com.barclaycard.interviews.airportbaggagerouting.beanmodal.VertexBean;
import com.barclaycard.interviews.airportbaggagerouting.service.ShortestPathAlgorithm;

/**
 * Created by rgalanki on 4/14/18
 */
public class ShortestPathAlgorithmImpl implements ShortestPathAlgorithm {

    private final static String SINGLE_WHITE_SPACE=" ";

    Map<String, ShortestPathGraphMap> visitedMap=new ConcurrentHashMap<>(); // Visited map with the sourceName as the key

    @Override
    public String findShortestPath(String entryGate, String destGate, List<DirectedEdgeBean> edges) {
        ShortestPathGraphMap dijkstraGraphMap;
        if(visitedMap.containsKey(entryGate)){
            dijkstraGraphMap = visitedMap.get(entryGate);
        }else {
            dijkstraGraphMap = new ShortestPathGraphMap(edges);
            dijkstraGraphMap.dijkstra(entryGate);
            visitedMap.put(entryGate,dijkstraGraphMap);
        }

        List<VertexBean> shortestPath= dijkstraGraphMap.getShortestPath(destGate);
        return generatePathLine(shortestPath);
    }

    private String generatePathLine(List<VertexBean> path){
        StringBuffer line = new StringBuffer();

        for(VertexBean vertex:path){
            line.append(vertex.getName()).append(SINGLE_WHITE_SPACE);
        }
        line.append(": ").append(path.get(path.size()-1).getTime());
        return line.toString();
    }

}
