package com.barclaycard.interviews.airportbaggagerouting.service;
import com.barclaycard.interviews.airportbaggagerouting.serviceImpl.*;
/**
 * Created by rgalanki on 4/14/18
 */
public class ShortestPathAlgorithmFactory {

    public static ShortestPathAlgorithm createDijkstraAlgorithm(){
        return new ShortestPathAlgorithmImpl();
    }
}
