package com.barclaycard.interviews.airportbaggagerouting.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.barclaycard.interviews.airportbaggagerouting.beanmodal.BagBean;
import com.barclaycard.interviews.airportbaggagerouting.beanmodal.DirectedEdgeBean;
import com.barclaycard.interviews.airportbaggagerouting.utility.AirportBaggageInputUtil;
import com.barclaycard.interviews.airportbaggagerouting.service.*;

/**
 * Created by rgalanki on 4/14/18.
 */
public class BaggageRoutingMainController {

    public static void main(String [] args){
        Scanner scan=null;
        if(args.length >0) {
            File inputDataFile=new File(args[0].trim());
            if(inputDataFile.exists()){
                try {
                    scan = new Scanner(inputDataFile);
                }catch (FileNotFoundException fnfex){
                    scan=AirportBaggageInputUtil.promptAndParse();
                }
            }else{
               scan=AirportBaggageInputUtil.promptAndParse();
            }
        }else
            scan=AirportBaggageInputUtil.promptAndParse();
        if(scan != null){
            List<DirectedEdgeBean> edges= AirportBaggageInputUtil.parseInputGraph(scan);
            ShortestPathAlgorithm dijkstraAlgorithm = ShortestPathAlgorithmFactory.createDijkstraAlgorithm();
            Map<String,String> departuresMap=AirportBaggageInputUtil.parseInputDepartures(scan); //Map with the flight as the key and the destination gate as the value
            List<BagBean> bagList = AirportBaggageInputUtil.parseInputBags(scan);
            scan.close();
            for(BagBean bag:bagList){
                String bagId=bag.getId();
                String entryGate=bag.getEntryGate();
                String flight = bag.getFlight();

                String destGate;
                if(flight.equals(AirportBaggageInputUtil.FLIGHT_ARRIVAL)){
                    destGate=AirportBaggageInputUtil.DEST_BAGGAGE_CLAIM;
                }else{
                    destGate=departuresMap.get(flight);
                }
                String pathLine=dijkstraAlgorithm.findShortestPath(entryGate,destGate,edges);

                System.out.println(bagId+AirportBaggageInputUtil.SINGLE_WHITE_SPACE+pathLine);
            }
        }

    }

}
