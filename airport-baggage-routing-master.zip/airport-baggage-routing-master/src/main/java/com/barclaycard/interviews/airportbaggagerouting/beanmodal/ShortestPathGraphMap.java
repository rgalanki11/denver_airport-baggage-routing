package com.barclaycard.interviews.airportbaggagerouting.beanmodal;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.TreeSet;

/**
 * Created by rgalanki on 4/14/18
 */
public class ShortestPathGraphMap {
    // mapping of vertex names to Vertex objects, built from a set of Edges
    private final Map<String, VertexBean> graphMap;
    public ShortestPathGraphMap(List<DirectedEdgeBean> directedEdges) {

        graphMap = new HashMap<>(directedEdges.size());

        //Populated all the vertices from the edges
        for (DirectedEdgeBean e : directedEdges) {
            if (!graphMap.containsKey(e.getSource().getName())) graphMap.put(e.getSource().getName(), new VertexBean(e.getSource().getName()));
            if (!graphMap.containsKey(e.getDestination().getName())) graphMap.put(e.getDestination().getName(), new VertexBean(e.getDestination().getName()));
        }

        //Set all the neighbours
        for (DirectedEdgeBean e : directedEdges) {
            graphMap.get(e.getSource().getName()).getNeighbours().put(graphMap.get(e.getDestination().getName()), e.getTime());
        }
    }


    /**
     * Runs dijkstra algorithm using a specified source vertex.
     * Every time when the starting vertex get changed, this algorithm should get run.
     * @param startName the starting or source Vertex for the path
     */
    public void dijkstra(String startName) {
        if (!graphMap.containsKey(startName)) {
            throw new ShortestPathGraphMapException("This DijkstraGraphMap does not contain the starting Vertex named:"+startName);
        }
        final VertexBean source = graphMap.get(startName);
        NavigableSet<VertexBean> queue = new TreeSet<>();

        // populate vertices to the queue
        for (VertexBean v : graphMap.values()) {
            v.setPrevVertext( v == source ? source : null);
            v.setTime(v == source ? 0 : Integer.MAX_VALUE);
            queue.add(v);
        }

        dijkstra(queue);
    }

    /**
     * Get the shortest path as a list of Vertex for a specific destination Vertex with name as endName
     * @param endName the destination vertex name
     * @return the shortest path as a List<Vertex>
     */

    public List<VertexBean> getShortestPath(String endName){
        if (!graphMap.containsKey(endName)) {
            throw new ShortestPathGraphMapException("Graph doesn't contain end vertex : "+endName);
        }

        return graphMap.get(endName).getShortestPathTo();
    }

    // Implementation of dijkstra's algorithm using a binary heap.
    private void dijkstra(final NavigableSet<VertexBean> que) {
        VertexBean source, neighbour;
        while (!que.isEmpty()) {

            source = que.pollFirst(); // vertex with shortest distance (first iteration will return source)
            if (source.getTime() == Integer.MAX_VALUE) break; // ignore u (and any other remaining vertices) since they are unreachable

            //look at distances to each neighbour
            for (Map.Entry<VertexBean, Integer> a : source.getNeighbours().entrySet()) {
                neighbour = a.getKey();

                final int alternateTime = source.getTime() + a.getValue();
                if (alternateTime < neighbour.getTime()) { // shorter path to neighbour found
                    que.remove(neighbour);
                    neighbour.setTime(alternateTime);
                    neighbour.setPrevVertext(source);
                    que.add(neighbour);
                }
            }
        }
    }
}
