package com.barclaycard.interviews.airportbaggagerouting.beanmodal;

/**
 * Created by rgalanki on 4/14/18
 */
public class DirectedEdgeBean {
    private final VertexBean source;
    private final VertexBean destination;
    private final int time;

    public DirectedEdgeBean(VertexBean source, VertexBean destination, int time) {
        this.source = source;
        this.destination = destination;
        this.time = time;
    }

    public DirectedEdgeBean(String sourceName, String destinationName, Integer time) {
        this.source = new VertexBean(sourceName);
        this.destination = new VertexBean(destinationName);
        this.time = time;
    }

    public VertexBean getSource() {
        return source;
    }

    public VertexBean getDestination() {
        return destination;
    }

    public int getTime() {
        return time;
    }
}
