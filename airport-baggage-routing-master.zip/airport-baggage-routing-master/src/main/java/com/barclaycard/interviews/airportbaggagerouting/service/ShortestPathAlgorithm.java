package com.barclaycard.interviews.airportbaggagerouting.service;

import java.util.List;

import com.barclaycard.interviews.airportbaggagerouting.beanmodal.DirectedEdgeBean;

/**
 * Created by rgalanki on 4/14/18.
 */
public interface ShortestPathAlgorithm {
    public String findShortestPath(String entry,String dest, List<DirectedEdgeBean> graphEdges);
}
